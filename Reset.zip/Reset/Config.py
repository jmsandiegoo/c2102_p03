config = {
##  'host': 'localhost',
##  'name': 'postgres',
##  'user': 'postgres',
  'pswd': '********'
}
